<?php 
/*
* Theme template for ht_kb_tag taxonomy
*/ 
?>

<?php get_header(); ?>


<?php hkb_get_template_part('hkb-compat', 'taxonomy'); ?>


<?php get_footer(); ?>