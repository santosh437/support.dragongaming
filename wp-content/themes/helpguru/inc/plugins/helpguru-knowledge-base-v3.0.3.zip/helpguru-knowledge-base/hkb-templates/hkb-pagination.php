<?php 
    if( function_exists( 'ht_pagination' ) ):
        ht_pagination();
    else:
        posts_nav_link();
    endif; 
